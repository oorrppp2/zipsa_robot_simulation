#include <ros/ros.h>
#include <iostream>
#include <fstream>
#include "move_base_msgs/MoveBaseActionGoal.h"

int main(int argc, char **argv) {
//    ros::init(argc,argv,"demo");
//    ros::NodeHandle nh;
//    ros::Publisher point_pub = nh.advertise<move_base_msgs::MoveBaseActionGoal>("/move_base/goal", 10);
//    move_base_msgs::MoveBaseActionGoal point_msg;

//    point_msg.header.stamp = ros::Time::now();
////    point_msg.header.frame_id = "map";
//    point_msg.goal.target_pose.pose.position.x = 1.0;
//    point_msg.goal.target_pose.pose.position.y = 1.0;

//    point_msg.goal.target_pose.pose.orientation.w = 1.0;

//    point_pub.publish(point_msg);
	return 0;
}
